library(e1071)
library(readxl)
nombre_archivo <- file.choose()
datos <- read_excel(nombre_archivo)
X <- datos[, 1:8]  
y <- datos[[9]]    
set.seed(123)
ind.train <- sample(1:nrow(datos), 200)
ind.train <- sort(ind.train)
x.train <- X[ind.train, ]
y.train <- y[ind.train]
x.test <- X[-ind.train, ]
y.test <- y[-ind.train]
svm_model <- svm(
  x = as.matrix(x.train),
  y = y.train,
  type = "eps-regression",
  kernel = "radial",
  epsilon = 0.1,
  cost = 100,
  gamma = 0.1,
  scale = TRUE
)
predicciones <- predict(svm_model, newdata = as.matrix(x.test))
error_absoluto_medio <- mean(abs(y.test - predicciones))
error_absoluto_medio
sd_error <- sd(abs(y.test - predicciones))
sd_error
plot(y.test, predicciones, main = "Real vs Prediccion", xlab = "Resistencia real (MPa)", ylab = "Predicción (MPa)")
abline(a = 0, b = 1, col = "red")