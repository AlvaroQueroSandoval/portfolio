import cv2
import numpy as np
import os
from datetime import datetime
from tensorflow.keras.models import load_model
from core_logic import adjust_brightness_contrast, enhance_black, four_point_transform, find_sudoku_contour, extract_cells, preprocess_cell, predict_board, solve, print_board


def process_sudoku_image(image_path, model):
    image = cv2.imread(image_path)
    image = adjust_brightness_contrast(image, brightness=15, contrast=40)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    contour = find_sudoku_contour(gray)
    if contour is None:
        raise ValueError("No se detectó el tablero.")
    
    warped = four_point_transform(image, contour)
    warped_gray = cv2.cvtColor(warped, cv2.COLOR_BGR2GRAY)
    warped_gray = enhance_black(warped_gray)

    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    processed_image_path = f'static/uploads/warped_{timestamp}.jpg'
    cv2.imwrite(processed_image_path, warped_gray)

    cells = extract_cells(warped_gray)
    board = predict_board(cells, model)

    # Clonar tablero antes de resolver
    solved_board = [row[:] for row in board]
    if not solve(solved_board):
        raise ValueError("No se pudo resolver el Sudoku.")

    return format_board(board), format_board(solved_board), processed_image_path

def format_board(board):
    output = ""
    for i, row in enumerate(board):
        if i % 3 == 0 and i != 0:
            output += "-" * 21 + "\n"
        row_str = ""
        for j, val in enumerate(row):
            if j % 3 == 0 and j != 0:
                row_str += "| "
            row_str += f"{val if val != 0 else '.'} "
        output += row_str + "\n"
    return output
