from flask import Flask, request, render_template, redirect, url_for  # ✅ correcto
from werkzeug.utils import secure_filename
import os
import cv2
import numpy as np
from tensorflow.keras.models import load_model
from sudoku_solver import process_sudoku_image, solve, print_board

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

# Cargar el modelo
model = load_model('sudoku_digit_model.h5')


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route('/', methods=['GET', 'POST'])
def index():
    return render_template('index.html')


@app.route('/solve', methods=['POST'])
def solve_sudoku():
    if 'image' not in request.files:
        return "No se subió ninguna imagen", 400

    file = request.files['image']

    if file.filename == '':
        return "Nombre de archivo vacío", 400

    if not allowed_file(file.filename):
        return "Formato de archivo no permitido. Usa PNG o JPG.", 400

    # Asegura que el directorio exista
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

    filename = secure_filename(file.filename)
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(filepath)

    try:
        board, solved_board, processed_image_path = process_sudoku_image(filepath, model)
    except Exception as e:
        return f"Error procesando imagen: {str(e)}", 500

    return render_template('result.html',
                           original_image=filepath,
                           processed_image=processed_image_path,
                           board=board,
                           solved_board=solved_board)


if __name__ == '__main__':
    app.run(debug=True)
