library(e1071)
datos <- read.table("adamantasa.txt", header = TRUE)
pulgadas <- datos[,1]
viga1 <- datos[,2]
viga2 <- datos[,3]
set.seed(123)
ind.train <- sample(1:314, 25)
ind.train <- sort(ind.train)
x.train <- pulgadas[ind.train]
y.train <- viga2[ind.train] 
x.test <- pulgadas[-ind.train]
y.test <- viga2[-ind.train]
svm_model <- svm(
  x = x.train,
  y = y.train,
  type = "eps-regression",
  kernel = "radial",
  epsilon = 0.02,
  cost = 100,
  gamma = 40,
  scale = FALSE
)
predicciones <- predict(svm_model, newdata = x.test)
error_absoluto_medio <- mean(abs(y.test - predicciones))
error_absoluto_medio
sd_error <- sd(abs(y.test - predicciones))
sd_error
plot(pulgadas, viga2, type = "l", col = "gray", lwd = 2, main = "Viga 2: Real vs Predicción")
points(x.train, y.train, col = "blue", pch = 16)
points(x.test, predicciones, col = "red", pch = 16, cex = 0.7)
legend("topright", legend = c("Real", "Datos reales", "Predicción"),
       col = c("gray", "blue", "red"), pch = c(1, 16, 16), lty = c(1, NA, NA))
tam_muestra <- c(10, 15, 20, 25, 30, 40, 50, 75, 100, 150)
errores <- numeric(length(tam_muestra))
for (i in seq_along(tam_muestra)) {
  n <- tam_muestra[i]
  set.seed(123)
  ind.train <- sample(1:314, n)
  ind.train <- sort(ind.train)
  x.train <- pulgadas[ind.train]
  y.train <- viga2[ind.train]
  x.test <- pulgadas[-ind.train]
  y.test <- viga2[-ind.train]
  svm_model <- svm(
    x = x.train,
    y = y.train,
    type = "eps-regression",
    kernel = "radial",
    epsilon = 0.02,
    cost = 100,
    gamma = 40,
    scale = FALSE
  )
  predicciones <- predict(svm_model, newdata = x.test)
  errores[i] <- mean(abs(y.test - predicciones))
}
resultados <- data.frame(Tamaño_de_muestra = tam_muestra, Error_Absoluto_Medio = errores)
print(resultados)
plot(tam_muestra, errores, type = "b", col = "blue", lwd = 2,
     xlab = "Muestra de entrenamiento",
     ylab = "Error absoluto medio (MAE)",
     main = "MAE vs Número de puntos usados para entrenamiento")

grid()