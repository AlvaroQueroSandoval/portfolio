import cv2
import numpy as np
import os
from tensorflow.keras.models import load_model


def adjust_brightness_contrast(image, brightness=15, contrast=40):
    alpha = contrast / 127 + 1.0
    beta = brightness
    return cv2.convertScaleAbs(image, alpha=alpha, beta=beta)


def enhance_black(image):
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    return clahe.apply(image)


def order_points(pts):
    s = pts.sum(axis=1)
    diff = np.diff(pts, axis=1)
    return np.array([
        pts[np.argmin(s)],
        pts[np.argmin(diff)],
        pts[np.argmax(s)],
        pts[np.argmax(diff)]
    ], dtype="float32")


def four_point_transform(image, pts):
    rect = order_points(pts)
    (tl, tr, br, bl) = rect
    widthA = np.linalg.norm(br - bl)
    widthB = np.linalg.norm(tr - tl)
    maxWidth = int(max(widthA, widthB))
    heightA = np.linalg.norm(tr - br)
    heightB = np.linalg.norm(tl - bl)
    maxHeight = int(max(heightA, heightB))
    dst = np.array([
        [0, 0],
        [maxWidth - 1, 0],
        [maxWidth - 1, maxHeight - 1],
        [0, maxHeight - 1]], dtype="float32")
    M = cv2.getPerspectiveTransform(rect, dst)
    return cv2.warpPerspective(image, M, (maxWidth, maxHeight))


def find_sudoku_contour(gray):
    blur = cv2.GaussianBlur(gray, (9, 9), 0)
    thresh = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C,
                                   cv2.THRESH_BINARY_INV, 11, 2)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    contours = sorted(contours, key=cv2.contourArea, reverse=True)
    for c in contours:
        approx = cv2.approxPolyDP(c, 0.02 * cv2.arcLength(c, True), True)
        if len(approx) == 4:
            return approx.reshape(4, 2)
    return None


def extract_cells(warped_gray):
    height, width = warped_gray.shape
    step_y = height // 9
    step_x = width // 9
    margin = 8
    cells = []
    for y in range(9):
        row = []
        for x in range(9):
            x1 = x * step_x + margin
            y1 = y * step_y + margin
            x2 = (x + 1) * step_x - margin
            y2 = (y + 1) * step_y - margin
            cell = warped_gray[y1:y2, x1:x2]
            row.append(cell)
        cells.append(row)
    return cells


import cv2
import numpy as np

def preprocess_cell(cell):
    if len(cell.shape) == 3:
        cell = cv2.cvtColor(cell, cv2.COLOR_BGR2GRAY)

    # Contraste local
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    cell = clahe.apply(cell)

    # Escalar para mejor detalle (dígitos delgados)
    cell = cv2.resize(cell, None, fx=3.5, fy=3.5, interpolation=cv2.INTER_LINEAR)

    # Suavizar ruido
    blur = cv2.GaussianBlur(cell, (3, 3), 0)

    # Binarización combinada
    adaptive = cv2.adaptiveThreshold(blur, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                     cv2.THRESH_BINARY_INV, 11, 2)
    _, otsu = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    thresh = cv2.bitwise_or(adaptive, otsu)

    # Engrosar trazos finos
    kernel = np.ones((2, 2), np.uint8)
    thresh = cv2.dilate(thresh, kernel, iterations=1)

    # Contornos
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None

    c = max(contours, key=cv2.contourArea)
    x, y, w, h = cv2.boundingRect(c)

    if w * h < 50:
        return None

    digit = thresh[y:y+h, x:x+w]
    h_digit, w_digit = digit.shape
    if h_digit == 0 or w_digit == 0:
        return None

    # Redimensionar proporcionalmente a 20x20
    scale = 20.0 / max(w_digit, h_digit)
    new_w = max(1, int(w_digit * scale))
    new_h = max(1, int(h_digit * scale))
    digit = cv2.resize(digit, (new_w, new_h), interpolation=cv2.INTER_AREA)

    # Centrado en 28x28
    mask = np.zeros((28, 28), dtype="uint8")
    top = (28 - new_h) // 2
    left = (28 - new_w) // 2
    mask[top:top + new_h, left:left + new_w] = digit

    # Validar contenido
    if cv2.countNonZero(mask) < 15:
        return None

    norm = mask.astype("float32") / 255.0
    return norm.reshape(1, 28, 28, 1)


def predict_board(cells, model, threshold=0.65):  # Bajamos el threshold
    board = []
    for row in cells:
        row_digits = []
        for cell in row:
            if np.mean(cell) > 240 or cv2.countNonZero(cell) < 30:  # Más permisivo
                row_digits.append(0)
                continue

            x = preprocess_cell(cell)
            if x is None:
                row_digits.append(0)
                continue

            pred = model.predict(x, verbose=0)
            digit = int(np.argmax(pred))
            confidence = pred[0][digit]

            # Aceptamos predicciones dudosas con menor threshold
            row_digits.append(digit if confidence > threshold else 0)
        board.append(row_digits)
    return board


def is_valid(board, row, col, num):
    if num in board[row]: return False
    if num in [board[i][col] for i in range(9)]: return False
    y0, x0 = 3 * (row // 3), 3 * (col // 3)
    for i in range(3):
        for j in range(3):
            if board[y0 + i][x0 + j] == num:
                return False
    return True


def solve(board, steps=None):
    for y in range(9):
        for x in range(9):
            if board[y][x] == 0:
                for n in range(1, 10):
                    if is_valid(board, y, x, n):
                        board[y][x] = n
                        if steps is not None:
                            steps.append([row[:] for row in board])
                        if solve(board, steps):
                            return True
                        board[y][x] = 0
                return False
    return True



def print_board(board):
    for i, row in enumerate(board):
        if i % 3 == 0 and i != 0:
            print("-" * 21)
        row_str = ""
        for j, val in enumerate(row):
            if j % 3 == 0 and j != 0:
                row_str += "| "
            row_str += f"{val if val != 0 else '.'} "
        print(row_str)


# -------------------------------
def main():
    model = load_model("sudokuu.h5")
    image = cv2.imread("ImagenesSudokus\sudoku5.png")
    if image is None:
        raise FileNotFoundError("No se encontró la imagen.")

    # 1. Brillo y contraste
    image = adjust_brightness_contrast(image, brightness=15, contrast=40)

    # 2. Escala de grises para contorno
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # 3. Encontrar el contorno del Sudoku
    contour = find_sudoku_contour(gray)
    if contour is None:
        raise Exception("No se detectó el tablero.")

    # 4. Aplicar warp para alinear la imagen
    warped = four_point_transform(image, contour)

    # 5. Convertir a escala de grises final y mejorar negros
    warped_gray = cv2.cvtColor(warped, cv2.COLOR_BGR2GRAY)
    warped_gray = enhance_black(warped_gray)

    # ✅ Guardar imagen antes de dividir
    os.makedirs("pruebas", exist_ok=True)
    cv2.imwrite("pruebas/imagen_filtrada_final.jpg", warped_gray)

    # 6. Cortar las celdas
    cells = extract_cells(warped_gray)

    # ✅ Guardar las 81 celdas
    os.makedirs("pruebas/celdas", exist_ok=True)
    for i, row in enumerate(cells):
        for j, cell in enumerate(row):
            filename = f"pruebas/celdas/celda_{i}_{j}.jpg"
            cv2.imwrite(filename, cell)

    # 7. Predecir contenido de las celdas
    board = predict_board(cells , model)

    print("\n🔢 Sudoku detectado:")
    print_board(board)

    if solve(board):
        print("\n✅ Sudoku resuelto:")
        print_board(board)
    else:
        print("\n❌ No se pudo resolver el Sudoku.")


if __name__ == "__main__":
    main()