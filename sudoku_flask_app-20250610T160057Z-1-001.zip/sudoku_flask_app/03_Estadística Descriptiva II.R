datos <- read.table(file.choose(), header = TRUE)
#### PARTE 1 ####
hijos <- datos$x
frecuencias <- table(hijos)
barplot(frecuencias,
        main = "Diagrama de Barras",
        xlab = "Número de Hijos",
        ylab = "Frecuencia",
        col = "skyblue")
pie(frecuencias,
    main = "Diagrama de Sectores",
    col = rainbow(length(frecuencias)),
    labels = paste(names(frecuencias), "\n(", frecuencias, ")", sep=""))

#### PARTE 2 ####
ingresos <- datos$yaux
hist(ingresos,
     main = "Histograma de Ingresos Familiares",
     xlab = "Ingresos familiares",
     col = "lightgreen",
     border = "black")
stem(ingresos)
#### PARTE 3 ####
media_X <- mean(hijos)
media_Y <- mean(ingresos)
mediana_X <- median(hijos)
mediana_Y <- median(ingresos)
moda_X <- as.numeric(names(sort(table(hijos), decreasing = TRUE)[1]))
cuartiles_X <- quantile(hijos, probs = c(0.25, 0.75))
cuartiles_Y <- quantile(ingresos, probs = c(0.25, 0.75))
deciles_X <- quantile(hijos, probs = c(0.2, 0.9))
deciles_Y <- quantile(ingresos, probs = c(0.2, 0.9))
varianza_X <- var(hijos)
varianza_Y <- var(ingresos)
quasi_varianza_X <- sum((hijos - mean(hijos))^2) / length(hijos)
quasi_varianza_Y <- sum((ingresos - mean(ingresos))^2) / length(ingresos)
desv_est_X <- sd(hijos)
desv_est_Y <- sd(ingresos)
rango_X <- max(hijos) - min(hijos)
rango_Y <- max(ingresos) - min(ingresos)
RIC_X <- IQR(hijos)
RIC_Y <- IQR(ingresos)
boxplot(hijos,
        main = "Diagrama de Cajas",
        ylab = "Número de Hijos",
        col = "lightblue")
boxplot(ingresos,
        main = "Diagrama de Cajas",
        ylab = "Ingresos Familiares",
        col = "lightgreen")


install.packages("e1071")
library(e1071)
asimetria_X <- skewness(hijos)
asimetria_Y <- skewness(ingresos)
curtosis_X <- kurtosis(hijos)
curtosis_Y <- kurtosis(ingresos)