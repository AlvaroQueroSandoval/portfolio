# IA para Gestión de Proyectos Software

Esta aplicación centraliza las funcionalidades de IA para ayudar al jefe de proyecto en sus tareas diarias.

## Características

- Dashboard centralizado
- Planificación asistida por IA
- Seguimiento de proyectos
- Gestión de documentación
- Gestión de equipo
- Control de costes

## Requisitos

- Python 3.8 o superior
- Dependencias listadas en `requirements.txt`

## Instalación

1. Clonar el repositorio
2. Crear un entorno virtual:
```bash
python -m venv venv
source venv/bin/activate  # En Windows: venv\Scripts\activate
```
3. Instalar dependencias:
```bash
pip install -r requirements.txt
```

## Configuración

1. Crear un archivo `.env` en la raíz del proyecto
2. Añadir las variables de entorno necesarias:
```
OPENAI_API_KEY=tu_api_key
```

## Ejecución

```bash
streamlit run main.py
```

## Estructura del Proyecto

- `main.py`: Aplicación principal
- `requirements.txt`: Dependencias del proyecto
- `.env`: Variables de entorno (no incluido en el repositorio) 