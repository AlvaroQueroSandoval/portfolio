import streamlit as st
import os
from dotenv import load_dotenv
from src.sections import dashboard, planificacion, seguimiento, documentacion, equipo, costes

# Cargar variables de entorno
load_dotenv()

# Configuración de la página
st.set_page_config(
    page_title="IA para Gestión de Proyectos Software",
    page_icon="🤖",
    layout="wide"
)

# Título principal
st.title("🤖 IA para Gestión de Proyectos Software")
st.markdown("Herramienta centralizada para potenciar la gestión de proyectos con IA")

# Sidebar para navegación
st.sidebar.title("Menú")
page = st.sidebar.radio(
    "Selecciona una sección:",
    ["Dashboard", "Planificación", "Seguimiento", "Documentación", "Equipo", "Costes"]
)

# Navegación principal
if page == "Dashboard":
    dashboard.show()
elif page == "Planificación":
    planificacion.show()
elif page == "Seguimiento":
    seguimiento.show()
elif page == "Documentación":
    documentacion.show()
elif page == "Equipo":
    equipo.show()
elif page == "Costes":
    costes.show()

# Footer
st.markdown("---")
st.markdown("Desarrollado para el Máster en IA y Big Data")
