import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import datetime, timedelta

def show():
    st.header("Seguimiento del Proyecto")
    st.write("Monitoreo y seguimiento de tareas")
    
    # Tabs para diferentes vistas
    tab1, tab2, tab3 = st.tabs(["Vista General", "Sprint Actual", "Burndown Chart"])
    
    with tab1:
        st.subheader("Estado General del Proyecto")
        
        # Métricas principales
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Tareas Pendientes", "12", "-2")
        with col2:
            st.metric("Tareas en Progreso", "8", "+3")
        with col3:
            st.metric("Tareas Completadas", "45", "+5")
        
        # Gráfico de estado de tareas
        estado_data = {
            'Estado': ['Pendiente', 'En Progreso', 'Completada', 'Bloqueada'],
            'Cantidad': [12, 8, 45, 3]
        }
        df_estado = pd.DataFrame(estado_data)
        fig_estado = px.pie(df_estado, values='Cantidad', names='Estado', title='Distribución de Tareas')
        st.plotly_chart(fig_estado)
    
    with tab2:
        st.subheader("Sprint Actual")
        
        # Información del sprint
        st.info("Sprint 3 - Semana 2/3")
        
        # Lista de tareas del sprint
        sprint_tareas = {
            'Tarea': ['Implementar Login', 'Diseñar API', 'Tests Unitarios', 'Documentación'],
            'Asignado': ['Juan', 'María', 'Carlos', 'Ana'],
            'Estado': ['En Progreso', 'Completada', 'Pendiente', 'En Progreso'],
            'Progreso': [75, 100, 0, 30]
        }
        df_sprint = pd.DataFrame(sprint_tareas)
        st.dataframe(df_sprint)
        
        # Gráfico de progreso del sprint
        fig_sprint = px.bar(df_sprint, x='Tarea', y='Progreso', title='Progreso de Tareas en Sprint')
        st.plotly_chart(fig_sprint)
    
    with tab3:
        st.subheader("Burndown Chart")
        
        # Datos de ejemplo para el burndown chart
        fechas = pd.date_range(start='2024-03-01', periods=14, freq='D')
        burndown_data = {
            'Fecha': fechas,
            'Tareas Restantes': [20, 18, 17, 15, 14, 12, 10, 9, 8, 7, 5, 4, 3, 2]
        }
        df_burndown = pd.DataFrame(burndown_data)
        
        # Línea ideal
        ideal_data = {
            'Fecha': fechas,
            'Tareas Restantes': [20, 18.57, 17.14, 15.71, 14.29, 12.86, 11.43, 10, 8.57, 7.14, 5.71, 4.29, 2.86, 1.43]
        }
        df_ideal = pd.DataFrame(ideal_data)
        
        # Gráfico de burndown
        fig_burndown = px.line(df_burndown, x='Fecha', y='Tareas Restantes', title='Burndown Chart')
        fig_burndown.add_scatter(x=df_ideal['Fecha'], y=df_ideal['Tareas Restantes'], 
                               mode='lines', name='Línea Ideal', line=dict(dash='dash'))
        st.plotly_chart(fig_burndown)
    
    # Sección de alertas y riesgos
    st.subheader("Alertas y Riesgos")
    with st.expander("Ver detalles"):
        st.warning("⚠️ 2 tareas en riesgo de no completarse en el sprint")
        st.error("❌ Bloqueo en la integración con el sistema de pagos")
        st.info("ℹ️ 3 tareas requieren revisión de código") 