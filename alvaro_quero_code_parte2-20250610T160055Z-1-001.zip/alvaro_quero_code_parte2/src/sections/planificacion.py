import streamlit as st
import pandas as pd
from datetime import datetime, timedelta

def show():
    st.header("Planificación con IA")
    st.write("Herramientas de planificación asistidas por IA")
    
    # Sección de creación de tareas
    st.subheader("Crear Nueva Tarea")
    with st.form("nueva_tarea"):
        titulo = st.text_input("Título de la tarea")
        descripcion = st.text_area("Descripción")
        prioridad = st.selectbox("Prioridad", ["Alta", "Media", "Baja"])
        fecha_inicio = st.date_input("Fecha de inicio")
        fecha_fin = st.date_input("Fecha de fin estimada")
        responsable = st.text_input("Responsable")
        
        submitted = st.form_submit_button("Crear Tarea")
        if submitted:
            st.success("Tarea creada exitosamente")
    
    # Sección de estimación de esfuerzo con IA
    st.subheader("Estimación de Esfuerzo con IA")
    with st.expander("Estimar esfuerzo de tarea"):
        descripcion_tarea = st.text_area("Describe la tarea a estimar")
        if st.button("Estimar con IA"):
            # Aquí iría la integración con el modelo de IA
            st.info("Estimación generada por IA: 3 días")
    
    # Vista de tareas planificadas
    st.subheader("Tareas Planificadas")
    tareas_data = {
        'Tarea': ['Desarrollo Frontend', 'Testing Backend', 'Documentación API'],
        'Prioridad': ['Alta', 'Media', 'Baja'],
        'Estado': ['En Progreso', 'Pendiente', 'Completada'],
        'Fecha Inicio': ['2024-03-01', '2024-03-05', '2024-03-10'],
        'Fecha Fin': ['2024-03-15', '2024-03-20', '2024-03-25']
    }
    df = pd.DataFrame(tareas_data)
    st.dataframe(df) 