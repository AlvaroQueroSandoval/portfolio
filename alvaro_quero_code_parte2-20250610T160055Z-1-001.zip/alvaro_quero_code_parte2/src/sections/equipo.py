import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import datetime, timedelta

def show():
    st.header("Gestión de Equipo")
    st.write("Herramientas para la gestión del equipo")
    
    # Tabs para diferentes vistas
    tab1, tab2, tab3 = st.tabs(["Miembros", "Rendimiento", "Asignaciones"])
    
    with tab1:
        st.subheader("Miembros del Equipo")
        
        # Lista de miembros del equipo
        equipo_data = {
            'Nombre': ['Juan Pérez', 'María García', 'Carlos López', 'Ana Martínez'],
            'Rol': ['Desarrollador Senior', 'Product Owner', 'QA Engineer', 'DevOps'],
            'Proyectos': ['3', '2', '2', '3'],
            'Disponibilidad': ['80%', '100%', '90%', '85%']
        }
        df_equipo = pd.DataFrame(equipo_data)
        st.dataframe(df_equipo)
        
        # Gráfico de distribución de roles
        roles_data = {
            'Rol': ['Desarrolladores', 'QA', 'DevOps', 'Product Owner'],
            'Cantidad': [5, 2, 2, 1]
        }
        df_roles = pd.DataFrame(roles_data)
        fig_roles = px.pie(df_roles, values='Cantidad', names='Rol', title='Distribución de Roles')
        st.plotly_chart(fig_roles)
    
    with tab2:
        st.subheader("Rendimiento del Equipo")
        
        # Métricas de rendimiento
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Velocidad del Equipo", "45 puntos", "+5")
        with col2:
            st.metric("Tasa de Completitud", "85%", "+2%")
        with col3:
            st.metric("Calidad del Código", "92%", "+3%")
        
        # Gráfico de rendimiento individual
        rendimiento_data = {
            'Miembro': ['Juan', 'María', 'Carlos', 'Ana'],
            'Tareas Completadas': [15, 12, 10, 8],
            'Calidad': [95, 90, 85, 88]
        }
        df_rendimiento = pd.DataFrame(rendimiento_data)
        fig_rendimiento = px.bar(df_rendimiento, x='Miembro', y=['Tareas Completadas', 'Calidad'],
                               title='Rendimiento Individual', barmode='group')
        st.plotly_chart(fig_rendimiento)
    
    with tab3:
        st.subheader("Asignación de Tareas")
        
        # Formulario de asignación
        with st.form("asignacion_tarea"):
            st.subheader("Nueva Asignación")
            tarea = st.text_input("Tarea")
            miembro = st.selectbox("Asignar a", ['Juan Pérez', 'María García', 'Carlos López', 'Ana Martínez'])
            prioridad = st.selectbox("Prioridad", ["Alta", "Media", "Baja"])
            fecha_limite = st.date_input("Fecha límite")
            
            submitted = st.form_submit_button("Asignar Tarea")
            if submitted:
                st.success("Tarea asignada exitosamente")
        
        # Vista de asignaciones actuales
        st.subheader("Asignaciones Actuales")
        asignaciones = {
            'Tarea': ['Desarrollo Frontend', 'Testing API', 'Documentación', 'Despliegue'],
            'Asignado': ['Juan Pérez', 'María García', 'Carlos López', 'Ana Martínez'],
            'Prioridad': ['Alta', 'Media', 'Baja', 'Alta'],
            'Estado': ['En Progreso', 'Pendiente', 'Completada', 'En Progreso']
        }
        df_asignaciones = pd.DataFrame(asignaciones)
        st.dataframe(df_asignaciones)
    
    # Sección de recomendaciones de IA
    st.subheader("Recomendaciones de IA")
    with st.expander("Ver recomendaciones"):
        st.info("🤖 Recomendación: Reasignar 2 tareas para balancear la carga de trabajo")
        st.info("🤖 Sugerencia: Programar sesión de pair programming entre Juan y Ana")
        st.info("🤖 Análisis: El equipo está trabajando de manera eficiente") 