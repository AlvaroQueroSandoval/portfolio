import streamlit as st
import pandas as pd
import plotly.express as px

def show():
    st.header("Dashboard Principal")
    st.write("Vista general del proyecto y KPIs principales")
    
    # Crear tres columnas para los KPIs principales
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric(label="Tareas Completadas", value="75%", delta="5%")
    
    with col2:
        st.metric(label="Presupuesto Utilizado", value="60%", delta="-2%")
    
    with col3:
        st.metric(label="Sprint Velocity", value="85%", delta="10%")
    
    # Gráfico de progreso del proyecto
    st.subheader("Progreso del Proyecto")
    progress_data = {
        'Fase': ['Planificación', 'Desarrollo', 'Testing', 'Despliegue'],
        'Progreso': [100, 75, 45, 20]
    }
    df = pd.DataFrame(progress_data)
    fig = px.bar(df, x='Fase', y='Progreso', title='Progreso por Fase')
    st.plotly_chart(fig)
    
    # Sección de alertas y notificaciones
    st.subheader("Alertas y Notificaciones")
    with st.expander("Ver alertas"):
        st.warning("⚠️ Sprint actual en riesgo de no completarse a tiempo")
        st.info("ℹ️ Nueva documentación disponible para revisión")
        st.error("❌ 3 tareas bloqueadas requieren atención") 