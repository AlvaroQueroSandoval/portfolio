import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import datetime, timedelta

def show():
    st.header("Control de Costes")
    st.write("Herramientas para el control de costes")
    
    # Tabs para diferentes vistas
    tab1, tab2, tab3 = st.tabs(["Presupuesto", "Gastos", "Predicciones"])
    
    with tab1:
        st.subheader("Presupuesto del Proyecto")
        
        # Métricas principales
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Presupuesto Total", "€100,000", "")
        with col2:
            st.metric("Gastado", "€45,000", "+€5,000")
        with col3:
            st.metric("Restante", "€55,000", "-€5,000")
        
        # Desglose del presupuesto
        presupuesto_data = {
            'Categoría': ['Desarrollo', 'Infraestructura', 'Testing', 'Documentación'],
            'Presupuesto': [50000, 20000, 15000, 15000],
            'Gastado': [25000, 8000, 7000, 5000]
        }
        df_presupuesto = pd.DataFrame(presupuesto_data)
        
        # Gráfico de presupuesto vs gastado
        fig_presupuesto = px.bar(df_presupuesto, x='Categoría', 
                               y=['Presupuesto', 'Gastado'],
                               title='Presupuesto vs Gastado por Categoría',
                               barmode='group')
        st.plotly_chart(fig_presupuesto)
    
    with tab2:
        st.subheader("Gastos del Proyecto")
        
        # Formulario de nuevo gasto
        with st.form("nuevo_gasto"):
            st.subheader("Registrar Nuevo Gasto")
            concepto = st.text_input("Concepto")
            categoria = st.selectbox("Categoría", 
                                  ["Desarrollo", "Infraestructura", "Testing", "Documentación"])
            monto = st.number_input("Monto (€)", min_value=0.0)
            fecha = st.date_input("Fecha")
            
            submitted = st.form_submit_button("Registrar Gasto")
            if submitted:
                st.success("Gasto registrado exitosamente")
        
        # Lista de gastos recientes
        st.subheader("Gastos Recientes")
        gastos_data = {
            'Fecha': ['2024-03-20', '2024-03-19', '2024-03-18', '2024-03-17'],
            'Concepto': ['Servicios Cloud', 'Licencias', 'Herramientas', 'Capacitación'],
            'Categoría': ['Infraestructura', 'Desarrollo', 'Testing', 'Documentación'],
            'Monto': [2000, 1500, 800, 1200]
        }
        df_gastos = pd.DataFrame(gastos_data)
        st.dataframe(df_gastos)
    
    with tab3:
        st.subheader("Predicciones de Costes con IA")
        
        # Predicción de costes futuros
        st.info("Predicción de costes para los próximos 3 meses")
        
        # Datos de ejemplo para la predicción
        meses = ['Abril', 'Mayo', 'Junio']
        prediccion_data = {
            'Mes': meses,
            'Predicción': [15000, 18000, 20000],
            'Límite Superior': [18000, 21000, 23000],
            'Límite Inferior': [12000, 15000, 17000]
        }
        df_prediccion = pd.DataFrame(prediccion_data)
        
        # Gráfico de predicción
        fig_prediccion = px.line(df_prediccion, x='Mes', y=['Predicción', 'Límite Superior', 'Límite Inferior'],
                               title='Predicción de Costes Mensuales')
        st.plotly_chart(fig_prediccion)
        
        # Análisis de riesgos
        st.subheader("Análisis de Riesgos de Costes")
        with st.expander("Ver análisis"):
            st.warning("⚠️ Posible sobrecoste en la fase de testing")
            st.info("ℹ️ Ahorro potencial identificado en licencias")
            st.error("❌ Riesgo de exceder presupuesto en desarrollo")
    
    # Sección de recomendaciones de IA
    st.subheader("Recomendaciones de IA")
    with st.expander("Ver recomendaciones"):
        st.info("🤖 Recomendación: Optimizar costes de infraestructura cloud")
        st.info("🤖 Sugerencia: Consolidar licencias de software")
        st.info("🤖 Análisis: El proyecto está dentro del presupuesto previsto") 