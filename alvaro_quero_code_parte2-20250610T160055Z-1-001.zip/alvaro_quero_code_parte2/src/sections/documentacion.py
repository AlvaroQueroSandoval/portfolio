import streamlit as st
import pandas as pd
from datetime import datetime

def show():
    st.header("Gestión de Documentación")
    st.write("Herramientas para documentación asistida por IA")
    
    # Tabs para diferentes tipos de documentación
    tab1, tab2, tab3 = st.tabs(["Documentos Técnicos", "Requisitos", "Manuales"])
    
    with tab1:
        st.subheader("Documentos Técnicos")
        
        # Lista de documentos técnicos
        docs_tecnicos = {
            'Documento': ['Arquitectura del Sistema', 'API REST', 'Base de Datos', 'Seguridad'],
            'Estado': ['Completado', 'En Revisión', 'Pendiente', 'Completado'],
            'Última Actualización': ['2024-03-15', '2024-03-20', '2024-03-25', '2024-03-10'],
            'Responsable': ['Juan', 'María', 'Carlos', 'Ana']
        }
        df_docs = pd.DataFrame(docs_tecnicos)
        st.dataframe(df_docs)
        
        # Generación de documentación con IA
        st.subheader("Generar Documentación con IA")
        with st.expander("Generar nuevo documento"):
            tipo_doc = st.selectbox("Tipo de documento", 
                                  ["Arquitectura", "API", "Base de Datos", "Seguridad"])
            descripcion = st.text_area("Descripción del sistema o componente")
            if st.button("Generar con IA"):
                st.info("Documento generado exitosamente")
    
    with tab2:
        st.subheader("Requisitos del Proyecto")
        
        # Lista de requisitos
        requisitos = {
            'ID': ['REQ-001', 'REQ-002', 'REQ-003', 'REQ-004'],
            'Descripción': ['Login de usuarios', 'Gestión de perfiles', 'Reportes', 'Exportación'],
            'Prioridad': ['Alta', 'Alta', 'Media', 'Baja'],
            'Estado': ['Implementado', 'En Progreso', 'Pendiente', 'Pendiente']
        }
        df_req = pd.DataFrame(requisitos)
        st.dataframe(df_req)
        
        # Análisis de requisitos con IA
        st.subheader("Análisis de Requisitos con IA")
        with st.expander("Analizar requisitos"):
            texto_requisito = st.text_area("Ingrese el requisito a analizar")
            if st.button("Analizar con IA"):
                st.info("Análisis completado: El requisito es claro y medible")
    
    with tab3:
        st.subheader("Manuales de Usuario")
        
        # Lista de manuales
        manuales = {
            'Manual': ['Usuario Final', 'Administrador', 'Desarrollador', 'Soporte'],
            'Versión': ['1.0', '1.0', '1.0', '1.0'],
            'Estado': ['Completado', 'En Revisión', 'Pendiente', 'Completado']
        }
        df_manuales = pd.DataFrame(manuales)
        st.dataframe(df_manuales)
        
        # Generación de manuales con IA
        st.subheader("Generar Manual con IA")
        with st.expander("Crear nuevo manual"):
            tipo_manual = st.selectbox("Tipo de manual", 
                                     ["Usuario Final", "Administrador", "Desarrollador", "Soporte"])
            funcionalidades = st.text_area("Funcionalidades a documentar")
            if st.button("Generar Manual con IA"):
                st.info("Manual generado exitosamente")
    
    # Sección de revisión de documentación
    st.subheader("Revisión de Documentación")
    with st.expander("Ver tareas de revisión"):
        st.warning("⚠️ 2 documentos pendientes de revisión")
        st.info("ℹ️ 1 manual requiere actualización")
        st.error("❌ 3 documentos con inconsistencias detectadas") 