import streamlit as st
import pandas as pd
from crewai import Agent
from fpdf import FPDF
from datetime import datetime
import random
import os
import json
import csv

# === CONFIGURACIÓN DE ARCHIVOS ===
counter_file_path = "factura_counter.json"
csv_file_path = "historial_facturas.csv"
precios_path = "precios_materiales.json"

# === FUNCIONES AUXILIARES ===
def obtener_siguiente_numero_factura():
    if os.path.exists(counter_file_path):
        with open(counter_file_path, "r") as f:
            data = json.load(f)
            numero = data.get("contador", 0) + 1
    else:
        numero = 1
    with open(counter_file_path, "w") as f:
        json.dump({"contador": numero}, f)
    return f"{numero:06d}"

def guardar_en_csv(numero_factura, cliente, direccion_obra, subtotal, iva, total):
    datos = {
        "NumeroFactura": numero_factura,
        "Cliente": cliente,
        "DireccionObra": direccion_obra,
        "Fecha": datetime.now().strftime('%Y-%m-%d'),
        "Subtotal": f"{subtotal:.2f}",
        "IVA": f"{iva:.2f}",
        "Total": f"{total:.2f}"
    }
    df_nueva = pd.DataFrame([datos])
    if os.path.exists(csv_file_path):
        df_existente = pd.read_csv(csv_file_path, encoding='utf-8', on_bad_lines='skip')
        df_actualizado = pd.concat([df_existente, df_nueva], ignore_index=True)
    else:
        df_actualizado = df_nueva
    df_actualizado.to_csv(csv_file_path, index=False, encoding='utf-8')

def cargar_precios():
    if os.path.exists(precios_path):
        with open(precios_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    else:
        return {
            "Aluminio": 4.80,
            "Vidrio": 12.00,
            "Cemento": 5.90,
            "Hierro": 3.50,
            "Ladrillos": 0.45
        }

def guardar_precios(precios):
    with open(precios_path, 'w', encoding='utf-8') as f:
        json.dump(precios, f, indent=2, ensure_ascii=False)
    st.session_state["precios_simulados"] = precios

# === AGENTES CREWAI ===
precio_agent = Agent(
    role="Consultor de Precios",
    goal="Buscar el precio actualizado de los materiales de construcción",
    backstory="Un experto en materiales de construcción con acceso a fuentes de precios confiables.",
    verbose=False
)

factura_agent = Agent(
    role="Generador de Facturas",
    goal="Calcular y generar facturas precisas a partir de los materiales seleccionados",
    backstory="Un asistente contable digital que automatiza la generación de facturas.",
    verbose=False
)

# === CÁLCULO DE FACTURA ===
def calcular_factura(materiales):
    detalles = []
    subtotal = 0
    for item in materiales:
        nombre = item["material"]
        cantidad = float(item["cantidad"])
        precio_unitario = item["precio"]
        subtotal_item = cantidad * precio_unitario
        subtotal += subtotal_item
        detalles.append({
            "nombre": nombre,
            "cantidad": cantidad,
            "precio_unitario": precio_unitario,
            "subtotal": subtotal_item
        })
    iva = subtotal * 0.21
    total = subtotal + iva
    return detalles, subtotal, iva, total

# === GENERADOR DE PDF ===
def generar_factura_pdf(cliente, direccion_obra, materiales, subtotal, iva, total):
    numero_factura = obtener_siguiente_numero_factura()
    ahora = datetime.now()
    carpeta = f"facturas/{ahora.year}/{ahora.strftime('%m')}"
    os.makedirs(carpeta, exist_ok=True)

    pdf = FPDF()
    pdf.add_page()
    logo_path = "aaa.jpg"
    if os.path.exists(logo_path):
        pdf.image(logo_path, x=10, y=8, w=30)

    pdf.set_font("Arial", "B", 14)
    pdf.set_xy(50, 10)
    pdf.cell(200, 10, "ConstruPlus S.L.", ln=1)
    pdf.set_font("Arial", "", 12)
    pdf.set_xy(50, 18)
    pdf.cell(200, 8, "CIF: B12345678", ln=1)
    pdf.set_xy(50, 26)
    pdf.cell(200, 8, "Dirección: Calle Falsa 123, Madrid, España", ln=1)
    pdf.set_xy(50, 34)
    pdf.cell(200, 8, "Email: info@construplus.com | Tel: +34 912 345 678", ln=1)
    pdf.set_xy(50, 42)
    pdf.cell(200, 8, f"Factura N.º: {numero_factura}", ln=1)
    pdf.set_xy(50, 50)
    pdf.cell(200, 8, f"Fecha: {datetime.now().strftime('%d/%m/%Y')}", ln=1)
    pdf.set_xy(10, 60)
    pdf.cell(200, 10, f"Cliente / Obra: {cliente}", ln=1)
    pdf.set_xy(10, 70)
    pdf.cell(200, 10, f"Dirección de la obra: {direccion_obra}", ln=1)
    pdf.ln(10)

    pdf.set_font("Arial", "B", 12)
    pdf.cell(60, 10, "Material", 1)
    pdf.cell(40, 10, "Cantidad", 1)
    pdf.cell(40, 10, "P. Unitario", 1)
    pdf.cell(40, 10, "Subtotal", 1)
    pdf.ln()

    pdf.set_font("Arial", "", 12)
    for mat in materiales:
        pdf.cell(60, 10, mat["nombre"], 1)
        pdf.cell(40, 10, str(mat["cantidad"]), 1)
        pdf.cell(40, 10, f"{mat['precio_unitario']:.2f} EUR", 1)
        pdf.cell(40, 10, f"{mat['subtotal']:.2f} EUR", 1)
        pdf.ln()

    pdf.cell(140, 10, "Subtotal", 1)
    pdf.cell(40, 10, f"{subtotal:.2f} EUR", 1)
    pdf.ln()
    pdf.cell(140, 10, "IVA (21%)", 1)
    pdf.cell(40, 10, f"{iva:.2f} EUR", 1)
    pdf.ln()
    pdf.cell(140, 10, "TOTAL", 1)
    pdf.cell(40, 10, f"{total:.2f} EUR", 1)
    pdf.ln(20)

    pdf.cell(200, 10, "Firma y Sello:", ln=1)
    pdf.rect(10, pdf.get_y(), 100, 30)

    filename = os.path.join(carpeta, f"factura_{numero_factura}.pdf")
    guardar_en_csv(numero_factura, cliente, direccion_obra, subtotal, iva, total)
    pdf.output(filename)
    return filename

# === INTERFAZ STREAMLIT ===
if "precios_simulados" not in st.session_state:
    st.session_state["precios_simulados"] = cargar_precios()
precios_simulados = st.session_state["precios_simulados"]

st.sidebar.title("Menú")
modo = st.sidebar.radio("Selecciona una opción", ["Generar factura", "Ver historial", "Administración"])

# === ADMINISTRACIÓN ===
if modo == "Administración":
    st.header("🔧 Administración de materiales y precios")

    with st.form("form_precios"):
        nuevo_material = st.text_input("Nuevo material")
        nuevo_precio = st.number_input("Precio del nuevo material (€/unidad)", min_value=0.0, step=0.01)
        agregar = st.form_submit_button("Añadir nuevo material")
        if agregar and nuevo_material:
            precios_simulados[nuevo_material] = nuevo_precio
            guardar_precios(precios_simulados)
            st.success(f"{nuevo_material} añadido con precio {nuevo_precio:.2f} €")

    st.subheader("📝 Lista de precios actuales")

    for mat, precio in list(precios_simulados.items()):
        col1, col2, col3 = st.columns([4, 4, 1])
        with col1:
            nuevo_valor = st.number_input(f"{mat}", value=precio, key=f"precio_{mat}", step=0.01)
            precios_simulados[mat] = nuevo_valor
        with col3:
            if st.button("❌", key=f"eliminar_{mat}"):
                precios_simulados.pop(mat)
                guardar_precios(precios_simulados)
                st.warning(f"Material eliminado: {mat}")
                st.rerun()

    if st.button("💾 Guardar cambios de precios"):
        guardar_precios(precios_simulados)
        st.success("Precios actualizados correctamente")

# === VER HISTORIAL ===
elif modo == "Ver historial":
    st.subheader("📄 Historial de facturas generadas")
    if os.path.exists(csv_file_path):
        df = pd.read_csv(csv_file_path, encoding='utf-8', on_bad_lines='skip')
        clientes = df['Cliente'].unique()
        años = df['Fecha'].apply(lambda x: x.split('-')[0]).unique()
        meses = df['Fecha'].apply(lambda x: x.split('-')[1]).unique()

        filtro_cliente = st.selectbox("Filtrar por cliente", ["Todos"] + list(clientes))
        filtro_año = st.selectbox("Filtrar por año", ["Todos"] + sorted(list(años)))
        filtro_mes = st.selectbox("Filtrar por mes", ["Todos"] + sorted(list(meses)))

        if filtro_cliente != "Todos":
            df = df[df['Cliente'] == filtro_cliente]
        if filtro_año != "Todos":
            df = df[df['Fecha'].str.startswith(filtro_año)]
        if filtro_mes != "Todos":
            df = df[df['Fecha'].str[5:7] == filtro_mes]

        st.dataframe(df)
        st.download_button(
            label="Descargar CSV filtrado",
            data=df.to_csv(index=False).encode('utf-8'),
            file_name="historial_filtrado.csv",
            mime="text/csv"
        )

# === GENERAR FACTURA ===
elif modo == "Generar factura":
    st.title("Generador Inteligente de Facturas de Construcción")
    cliente = st.text_input("Nombre de la obra o cliente")
    direccion_obra = st.text_input("Dirección de la obra")

    materiales_disponibles = list(precios_simulados.keys())
    n_materiales = st.number_input("¿Cuántos materiales vas a usar?", min_value=1, max_value=10, step=1)
    materiales_solicitados = []

    for i in range(n_materiales):
        col1, col2 = st.columns(2)
        with col1:
            mat = st.selectbox(f"Material {i+1}", materiales_disponibles, key=f"mat_{i}")
        with col2:
            cant = st.text_input(f"Cantidad (kg, m², etc.) del material {i+1}", key=f"cant_{i}")
        if mat and cant:
            precio = precios_simulados.get(mat, 1.0)
            materiales_solicitados.append({"material": mat, "cantidad": cant, "precio": precio})

    if st.button("Generar factura"):
        detalles, subtotal, iva, total = calcular_factura(materiales_solicitados)
        pdf_file = generar_factura_pdf(cliente, direccion_obra, detalles, subtotal, iva, total)
        st.success("Factura generada correctamente")
        st.download_button(
            "Descargar Factura PDF",
            data=open(pdf_file, "rb"),
            file_name=os.path.basename(pdf_file),
            mime="application/pdf"
        )
